//

#include<AHT20.h>  // AHT 20 sensor library , Temperature and humidity
#include<Arduino.h> // Buit in libraries for arduino functions
#include<BMP280.h>  // BMP 280 sensor , temperature , pressure
#include<EEPROM.h>  // Emulated EEPROM library uses a chunk from the flash storage , needs to be predefined in Kbytes
#include<HX1838Decoder.h> // Infrared receiver library
#include<I2C_RTC.h> // RTC chip handler , universal
#include<TM1637Display.h> // Display chip driver libary
#include<Wire.h> // I2C functions and communications

#define DS3231_ADDRES 0x68 // I2C address of the RTC chip used
#define CLK1 7
#define CLK2 3
#define DAT1 10
#define DAT2 2

#define ALARMOUT 21 // Toggle pin to start melody playback
#define ALARMIN 6 // Thip pin gets used for an easteregg 

#define I2C_SDA 8  // In case of multiple pins can have this function , we set to the default ones
#define I2C_SCL 9

int brightness = 0;      // This value is stored in EEPROM and detemined the brightness of the display on a scale of 0-7
int autobrightness = 0;  // Determines the illumination based brighness control behaviour, 0 off 1 on.
int timeformat = 0;    // This value tells if the format is 24 (0) / 12H (1)
int ldrvalue = 0;      // If set to 1 this will contain the read value of the LDR to be processed
int setbrightness = 0;  // This value is used to map the brightness according to voltage level if the autobrightness is active (1)
int hourlychime = 0;   // Contains the set value of give a chime at each hour passing , that will be read later and act accordingly
int lasthour = 0;  // Used with the check for chime statement and alarm

byte second , minute , hour , day , month, hrmode; // Used as variables when reading from the RTC 
int year = 0;     
int pmindicator = 0; // Used only when in 12HR format , to display morning and afternoon
int amindicator = 0;

byte setsecond , setminute , sethour , setday , setmonth; // Will be used to adjust and set the time and date
int setyear = 0;
int setpmindicator = 0;
int setamindicator = 0;


int tempint = 0; // For converint to int after reading bmp280 temperature
int tempinta = 0; // For converint to int after reading aht20 temperature
int pressureint = 0; // For converint to int after reading bmp280 pressure
int humint = 0; // For converint to int after reading aht20 humidity
int weeknum = 0; // Used for storing week number calculated

byte code; // Contins the code received by the IR sensor

int menuitem = 0; // Keeps track of  the menu item selected


static DS3231 RTC;      // The selected RTC chip to use

AHT20 aht20;  // Create instance of AHT for readig its values later in the code
BMP280 bmp280; // Create instance of BMP for reading its values later in the code

IRDecoder irDecoder(5); // Crate instance, Read codes on this pin when used with remote control

TM1637Display display2(CLK2,DAT2); // <-- Represnents the lower screen
TM1637Display display1(CLK1,DAT1); // <-- Represents the upper screen

const uint8_t CUSTOM_t = 0b1111000;
const uint8_t CUSTOM_I = 0b0000110;
const uint8_t CUSTOM_N = 0b1010100; // need to display twice for M
const uint8_t CUSTOM_b = 0b1111100;
const uint8_t CUSTOM_G = 0b1111101;
const uint8_t CUSTOM_H = 0b01110110;
const uint8_t CUSTOM_E = 0b1111001;
const uint8_t CUSTOM_d = 0b1011110;
const uint8_t CUSTOM_A = 0b1110111;
const uint8_t CUSTOM_U = 0b0111110;
const uint8_t CUSTOM_P = 0b1110011;
const uint8_t CUSTOM_R = 0b1010000;
const uint8_t CUSTOM_O = 0b0111111;
const uint8_t CUSTOM_S = 0b1101101;
const uint8_t CUSTOM_V = 0b0111110;
const uint8_t CUSTOM_0 = 0b0000000;
const uint8_t CUSTOM_Y = 0b1100110;
const uint8_t CUSTOM_C = 0b0111001;
const uint8_t CUSTOM_c = 0b1011000;
const uint8_t CUSTOM_C2 = 0b0001111;
const uint8_t CUSTOM_1 = 0b0000110;
const uint8_t CUSTOM_2 = 0b1011011;
const uint8_t CUSTOM_4 = 0b1100110;
const uint8_t CUSTOM_l = 0b0111000;


void LoadSettings()
{
  // Load configuration related to the behaviour of the clock
  // If an invalid value detected , then set defualts
  brightness = (EEPROM.read(0)); 
  autobrightness = (EEPROM.read(1));
  timeformat = (EEPROM.read(2));
  hourlychime = (EEPROM.read(3));

  if ( brightness < 0 || brightness > 7 ) // Less than 0 or greater than 7 then
  { // If this setting is invalid , a new device is being programmed , need to set defaults
    brightness = 3;
    autobrightness = 0;
    timeformat = 0;
    hourlychime = 0;
    EEPROM.write(0,brightness);
    EEPROM.write(1,autobrightness);
    EEPROM.write(2,timeformat);
    EEPROM.write(3,hourlychime);
    EEPROM.commit(); // Then save it 
  }

}

void CheckRTC()
{
if (!RTC.isRunning())
{
    // Set the time

   if ( timeformat == 0 ) // Check settings then set the timeformat
   {
      RTC.setHourMode(CLOCK_H24);
   } 
    
   else  // Set to 12H if needed
   {
      RTC.setHourMode(CLOCK_H12);   
   } 

  RTC.setSeconds(0);
  RTC.setMinutes(0);
  RTC.setHours(12);

    // Set the date

    RTC.setDay(1);
    RTC.setMonth(1);
    RTC.setYear(2024);  

    RTC.updateWeek(); // updates the week automatically based on date in the RTC.

}
  RTC.startClock();  // Yes ... this library needs the clock to be started... whatever.
}

void UseLDR()
{  // LDR is on Pin 4

  if (autobrightness == 1)
  { 
    ldrvalue = analogRead(4);
    delay(100);
    // min = 800
    // max = 1990
    if ( ldrvalue < 900 ) setbrightness = 2; // Near Lowest
     else if ( ldrvalue < 1200) setbrightness = 3; // Default
     else if ( ldrvalue < 1500) setbrightness = 4; // Better
     else if ( ldrvalue < 1800) setbrightness = 6; // Safe maximum
     else if ( ldrvalue < 2100) setbrightness = 7; // Absolute maximum
     else setbrightness = 7; // When its realyl bright , under light or sun shines directly

   display1.setBrightness(setbrightness); //Set screen 1 brightness according to the value set by ldrvalue
   display2.setBrightness(setbrightness); //Set screen 1 brightness according to the value set by ldrvalue

    }
  else
  {
    // Do nothing , continue with preset display brightness
  }
}

byte convertToSegment(byte number) {
  switch (number) {
    case 0: return 0x3F;
    case 1: return 0x06;
    case 2: return 0x5B;
    case 3: return 0x4F;
    case 4: return 0x66;
    case 5: return 0x6D;
    case 6: return 0x7D;
    case 7: return 0x07;
    case 8: return 0x7F;
    case 9: return 0x6F;
    default: return 0x00;
  }
}

void GetDateTime()
{
  if(RTC.isRunning()) // Check for the RTC running then get the values 
  {
   second = RTC.getSeconds();
   minute = RTC.getMinutes();
   hour = RTC.getHours(); 
   day = RTC.getDay();
   month = RTC.getMonth();
   year= RTC.getYear();
   hrmode = RTC.getHourMode();

     if (hrmode == CLOCK_H12) // Check for the 12HR mode and wheter its AM/PM , store the value to be displayed
     { 
      if(RTC.getMeridiem() == HOUR_AM) 
      { 
       amindicator = 1; 
       pmindicator = 0;
      } 
      if(RTC.getMeridiem() == HOUR_PM) 
      {
       pmindicator = 1; 
       amindicator = 0;
      }
     } 

  }

}

void DisplayTime()
{ 
  uint8_t displayData[6];

  displayData[0] = (hour / 10);
  displayData[1] = hour % 10;
  displayData[2] = (minute / 10);
  displayData[3] = minute % 10;
  displayData[4] = (second / 10);
  displayData[5] = second % 10;

  for (int i = 0; i < 6; i++)
  {
    displayData[i] = convertToSegment(displayData[i]);
  }

  uint8_t text[] =
  {
    displayData[0],
    displayData[1] | 0x80,
    displayData[2],
    displayData[3] | 0x80,
    displayData[4],
    displayData[5]
  };

  // Only difference
  if (hourlychime == 1)
  {
    text[5] |= 0x80;
  }

  display2.setSegments(text, 6, 0);
}

void Display12HTime()
{   
     
 uint8_t displayData[6];

  displayData[0] = (hour / 10);
  displayData[1] = hour % 10;
  displayData[2] = (minute / 10);
  displayData[3] = minute % 10;
  displayData[4] = (second / 10);
  displayData[5] = second % 10;

  for (int i = 0; i < 6; i++)
  {
    displayData[i] = convertToSegment(displayData[i]);
  }

  uint8_t text[] =
  {
    displayData[0],
    displayData[1] | 0x80,
    displayData[2],
    displayData[3] | 0x80,
    displayData[4],
    displayData[5]
  };

  // hourly chime → last decimal point
  if (hourlychime == 1)
  {
    text[5] |= 0x80;
  }

  // PM indicator → first digit decimal point
  if (pmindicator == 1)
  {
    text[0] |= 0x80;
  }

  display2.setSegments(text, 6, 0);
 }


void DisplayDate()
{
uint8_t displayData[6];
    displayData[0] = (year % 100 )/10;
    displayData[1] = year%10;
    displayData[2] = (month /10);
    displayData[3] = month%10;
    displayData[4] = (day/10);
    displayData[5] = day%10;

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {displayData[0], displayData[1] | 0x80, displayData[2], displayData[3] | 0x80, displayData[4], displayData[5]|0x80};
  display1.setSegments(text, 6, 0);
}

void ReadSensors()
{
  float temperature = bmp280.getTemperature();
  uint32_t pressure = bmp280.getPressure();
  float atemperature = aht20.getTemperature();
  float humidity = aht20.getHumidity();

   tempint = int(temperature);
   tempinta =int(atemperature);
   pressureint = int(pressure);
   humint = int(humidity);

}

void IRCodeHandler()
{
if (irDecoder.available())
 {
    code = (irDecoder.getDecodedData());
 }
  return;
}

void ProcessIRCode()
{
  switch ( code ) // Decides the case that will be activated according to the code received
   {
      case 0x5D:   // Button 1 presed on the remote
      DisplayTemp();
      delay(2000);
      code = 0;
      break;

      case 0x9D:  // Button 2 presed on the remote
      DisplayHum();
      delay(2000);
      code = 0;
      break;

      case 0x1D:  // Button 3 presed on the remote
      DisplayPress();
      delay(2000);
      code = 0;
      break;

      case 0x1F:  // Button 7 pressed on the remote
      DisplayWeek();
      delay(2000);
      code = 0;
      break;

      case 0x97: // Button * pressed on the remote
      Menu();
      break;

      case 0x57:  // 8 button is pressed on the remote
      CheckTimeMode();
      delay(2000);
      code = 0;
      break;

   }
     
}

void DisplayTempText()
{
uint8_t text[] = {CUSTOM_t, CUSTOM_E, CUSTOM_N, CUSTOM_N, CUSTOM_P,CUSTOM_0};
display1.setSegments(text, 6, 0);
}

void DisplayHumText()
{
uint8_t text[] = {CUSTOM_H, CUSTOM_U, CUSTOM_N, CUSTOM_N, CUSTOM_I, CUSTOM_d};
display1.setSegments(text, 6, 0);
}

void DisplayPessureText()
{
uint8_t text[] = {CUSTOM_P, CUSTOM_R, CUSTOM_E, CUSTOM_S, CUSTOM_S, CUSTOM_R};
display1.setSegments(text, 6, 0);
}

void DispayWeekText()
{
uint8_t text[] = {CUSTOM_V, CUSTOM_V, CUSTOM_E, CUSTOM_E, CUSTOM_H, CUSTOM_0};
display1.setSegments(text, 6, 0);  
}

void DisplayMenu()
{
uint8_t text[] = {CUSTOM_N, CUSTOM_N, CUSTOM_E, CUSTOM_N, CUSTOM_U, CUSTOM_0};
display1.setSegments(text, 6, 0);
}

void DisplaySetClock()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_C, CUSTOM_l, CUSTOM_H};
display2.setSegments(text, 6, 0);
}

void DisplaySetHour()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_H, CUSTOM_R, CUSTOM_0};
display1.setSegments(text, 6, 0);
}

void DisplaySetMinute()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_N, CUSTOM_N, CUSTOM_N};
display1.setSegments(text, 6, 0);
}

void DisplaySetSecond()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_S, CUSTOM_E, CUSTOM_C};
display1.setSegments(text, 6, 0);
}

void DisplaySetYear()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_Y, CUSTOM_R, CUSTOM_0};
display1.setSegments(text, 6, 0);
}

void DisplaySetMonth()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_N, CUSTOM_N, CUSTOM_t};
display1.setSegments(text, 6, 0);
}

void DisplaySetDay()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_d, CUSTOM_A, CUSTOM_Y};
display1.setSegments(text, 6, 0);
}

void DisplaySetBrightness()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_b, CUSTOM_R, CUSTOM_t};
display2.setSegments(text, 6, 0);
}

void DisplaySetAutoBrightness()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_A, CUSTOM_b, CUSTOM_R};
display2.setSegments(text, 6, 0);
}

void DisplaySetChime()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_C, CUSTOM_H, CUSTOM_N};
display2.setSegments(text, 6, 0);  
}

void DisplaySetChimeText()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_C, CUSTOM_H, CUSTOM_N};
display1.setSegments(text, 6, 0);  
}

void AutoText()
{
uint8_t text[] = {CUSTOM_A, CUSTOM_U, CUSTOM_t, CUSTOM_O, CUSTOM_0, CUSTOM_0};
display1.setSegments(text, 6, 0);  
}

void ActiveText()
{
uint8_t text[] = {CUSTOM_A, CUSTOM_C, CUSTOM_t, CUSTOM_I, CUSTOM_V, CUSTOM_E};
display2.setSegments(text, 6, 0);  
}

void SetAMPMText()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_P, CUSTOM_N, CUSTOM_N};
display1.setSegments(text, 6, 0); 
}

void DisplaySet1224H()
{
uint8_t text[] = {CUSTOM_S, CUSTOM_E, CUSTOM_t, CUSTOM_H, CUSTOM_N, CUSTOM_N};
display2.setSegments(text, 6, 0);  
}

void DisplayTM()
{
uint8_t text[] = {CUSTOM_t, CUSTOM_N, CUSTOM_N, CUSTOM_N, CUSTOM_N, CUSTOM_d};
display1.setSegments(text, 6, 0);
}

void DisplayTemp()
{
  ReadSensors();  // Read all data
  DisplayTempText();  // Display text on upper screen
  uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder only
    displayData[1] = CUSTOM_0;
    displayData[2] = (tempint /10);
    displayData[3] = tempint%10;
    displayData[4] = CUSTOM_0;
    displayData[5] = CUSTOM_0;

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3],CUSTOM_C|0x80, CUSTOM_0}; // Display temperature data on bottom screen , |0x80 puts the decmal point after the digit
  display2.setSegments(text, 6, 0); // Display it

} 

void DisplayHum()
{
  ReadSensors();
  DisplayHumText();
  uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder only
    displayData[1] = CUSTOM_0;
    displayData[2] = (humint /10);
    displayData[3] = humint%10;
    displayData[4] = CUSTOM_0;
    displayData[5] = CUSTOM_0;

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3],CUSTOM_H|0x80, CUSTOM_0}; // Display humidity data on bottom screen , |0x80 puts the decmal point after the digit
  display2.setSegments(text, 6, 0); // Display it 

}

void DisplayPress()
{
  ReadSensors();
  DisplayPessureText();
  pressureint = ( pressureint/100);  // Divide pascal value by 100 to get mbar
  uint8_t displayData[6];
    displayData[0] = (pressureint/1000); // Divide by 1000 to get first digit
    displayData[1] = (pressureint/100)%10; // Divide by 100 to get second digit , but constrain it to fit under 10 -> %10
    displayData[2] = (pressureint /10)%10; // Divide by 10 to third last digit , but constrain it to fit under 10 -> %10
    displayData[3] = pressureint%10;  // Get last digit , constrained to under 10 -> %10
    displayData[4] = CUSTOM_0;
    displayData[5] = CUSTOM_0;

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {displayData[0],displayData[1], displayData[2], displayData[3],CUSTOM_N, CUSTOM_b|0x80}; // Display pressure data on bottom screen , |0x80 puts the decmal point after the digit
  display2.setSegments(text, 6, 0); // Display it 
  

}

void DisplayWeek()
{
DispayWeekText();
  weeknum = GetWeekNumber();
uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (weeknum/10); // Week nuber /10 to get first digit 
    displayData[3] = (weeknum%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Display week number on bottom screen , |0x80 puts the decmal point after the digit
  display2.setSegments(text, 6, 0); // Display it

}

int GetWeekNumber()
{   // This function has been generated by ChatGPT , because the RTC library claims to have this function, and what it actually has is not related, but poorly documented
  int y = year;
  int m = month;
  int d = day;

  // day of year
  int doy = d;

  const int daysBeforeMonth[] =
  {0,31,59,90,120,151,181,212,243,273,304,334};

  doy += daysBeforeMonth[m-1];

  // leap year correction
  if (m > 2 && ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)))
    doy++;

  // weekday (Mon=1..Sun=7)
  int wday = RTC.getWeek();

  // convert Sunday=1 → ISO Monday=1
  wday = (wday == 1) ? 7 : wday - 1;

  // ISO week
  int week = (doy - wday + 10) / 7;

  if (week < 1) week = 1;
  if (week > 53) week = 53;
  weeknum = week;
  return week;
}

void SetYear()
{
   GetDateTime();
    setyear = year;
   bool yearadj = true;
 while ( yearadj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (setyear/10); // Week nuber /10 to get first digit 
    displayData[3] = (setyear%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set year number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      setyear = setyear+1;
      if (setyear > 99)
      setyear = 1;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    setyear = setyear-1;
      if (setyear < 1)
      setyear = 1;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     delay(100);
     code = 0;
     yearadj = false;
         // Exit and go to next function
   }  
 }
}

void SetMonth()
{
   GetDateTime();
    setmonth = month;
   bool monthadj = true;
 while ( monthadj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (setmonth/10); // Week nuber /10 to get first digit 
    displayData[3] = (setmonth%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set month number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      setmonth = setmonth+1;
      if (setmonth > 12)
      setmonth = 1;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    setmonth = setmonth-1;
      if (setmonth < 1)
      setmonth = 1;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     
    delay(100);
    code = 0;
    monthadj = false;
     // Exit and go to next function
   }  
 }
}

void SetDay()
{
   GetDateTime();
    setday = day;
   bool dayadj = true;
 while ( dayadj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (setday/10); // Week nuber /10 to get first digit 
    displayData[3] = (setday%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set day number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      setday = setday+1;
      if (setday > 31)
      setday = 1;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    setday = setday-1;
      if (setday < 1)
      setday = 1;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     
    delay(100);
    code = 0;
    dayadj = false;
     // Exit and go to next function
   }  
 }
}

void SetHour()
{ 
  if ( timeformat == 1)
     {
       GetDateTime();
    sethour = hour;
   bool houradj = true;
 while ( houradj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (sethour/10); // Week nuber /10 to get first digit 
    displayData[3] = (sethour%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set hour number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      sethour = sethour+1;
      if (sethour > 12)
      sethour = 1;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    sethour = sethour-1;
      if (sethour < 1)
      sethour = 1;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     
    delay(100);
    code = 0;
    houradj = false;
     // Exit and go to next function
   }  
 }
     }
 else
 {    
   GetDateTime();
    sethour = hour;
   bool houradj = true;
 while ( houradj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (sethour/10); // Week nuber /10 to get first digit 
    displayData[3] = (sethour%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set hour number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      sethour = sethour+1;
      if (sethour > 23)
      sethour = 0;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    sethour = sethour-1;
      if (sethour < 1)
      sethour = 1;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     
    delay(100);
    code = 0;
    houradj = false;
     // Exit and go to next function
       }  
     }
   }

}   

void SetMinute()
{
   GetDateTime();
    setminute = minute;
   bool minuteadj = true;
 while ( minuteadj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (setminute/10); // Week nuber /10 to get first digit 
    displayData[3] = (setminute%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set minute number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      setminute = setminute+1;
      if (setminute > 59)
      setminute = 0;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    setminute = setminute-1;
      if (setminute < 1)
      setminute = 1;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     
    delay(100);
    code = 0;
    minuteadj = false;
     // Exit and go to next function
   }  
 }
}

void SetSecond()
{
   GetDateTime();
    setsecond = second;
   bool secondadj = true;
 while ( secondadj)
  {  IRCodeHandler();

    uint8_t displayData[6];
    displayData[0] = CUSTOM_0; // Placeholder
    displayData[1] = CUSTOM_0; // Placeholder
    displayData[2] = (setsecond/10); // Week nuber /10 to get first digit 
    displayData[3] = (setsecond%10);
    displayData[4] = CUSTOM_0; // Placeholder
    displayData[5] = CUSTOM_0; // Placeholder

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, displayData[2], displayData[3]|0x80,CUSTOM_0, CUSTOM_0}; // Set second number
  display2.setSegments(text, 6, 0); // Display it

    if ( code == 0xE7 )  // Up button has been pushed
    {
      setsecond = setsecond+1;
      if (setsecond > 59)
      setsecond = 0;
    delay(100);
     code = 0; 
    }

   if ( code == 0xB5 ) // Down button has been pushed
   {
    setsecond = setsecond-1;
      if (setsecond < 1)
      setsecond = 0;
    delay(100);
    code = 0;
   }
   if ( code == 0xC7) // Okay button has been pushed
   {
     
    delay(100);
    code = 0;
    secondadj = false;
     // Exit and go to next function
   }  
 }
}


void SetDateTime()
{
  if ( timeformat == 1)
 {
  DisplaySetYear();
  SetYear();
  delay(100);
  DisplaySetMonth();
  SetMonth();
  delay(100);
  DisplaySetDay();
  SetDay();
  delay(100);
  DisplaySetHour();
  SetHour();
  SetAMPMText();
  Set1224H();
  delay(100);
  DisplaySetMinute();
  SetMinute();
  delay(100);
  DisplaySetSecond();
  SetSecond();
 delay(100); 
 RTC.stopClock();
 RTC.setHourMode(CLOCK_H12);
 RTC.setYear(setyear);
 RTC.setMonth(setmonth);
 RTC.setDay(setday);

 if ( pmindicator == 1)
  {
    RTC.setMeridiem(HOUR_PM);
  }
 else
  {
    RTC.setMeridiem(HOUR_AM);
  }

 RTC.setHours(sethour);
 RTC.setMinutes(setminute);
 RTC.setSeconds(setsecond);
 RTC.updateWeek();
 RTC.startClock();

 }

 else 
 {

  DisplaySetYear();
  SetYear();
  delay(100);
  DisplaySetMonth();
  SetMonth();
  delay(100);
  DisplaySetDay();
  SetDay();
  delay(100);
  DisplaySetHour();
  SetHour();
  delay(100);
  DisplaySetMinute();
  SetMinute();
  delay(100);
  DisplaySetSecond();
  SetSecond();
 delay(100);
 
 RTC.stopClock();
 RTC.setHourMode(CLOCK_H24);
 RTC.setYear(setyear);
 RTC.setMonth(setmonth);
 RTC.setDay(setday);
 RTC.setHours(sethour);
 RTC.setMinutes(setminute);
 RTC.setSeconds(setsecond);
 RTC.updateWeek();
 RTC.startClock();
 }
}

void SetBrightness()
{  code = 0;
 if ( autobrightness == 1)
    {
      AutoText();
      ActiveText();
      delay(2000);
    }
 else
  {   
  bool bright = true;
  
while (bright)
{
   IRCodeHandler();

   uint8_t displayData[6];
    displayData[0] = CUSTOM_l;
    displayData[1] = CUSTOM_V;
    displayData[2] = CUSTOM_l;
    displayData[3] = CUSTOM_0;  // Placeholder
    displayData[4] = (brightness/10);
    displayData[5] = (brightness%10);

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_l,CUSTOM_V,CUSTOM_l,CUSTOM_0, displayData[4],displayData[5]|0x80}; // Set brightness level 0-7
  display2.setSegments(text, 6, 0); // Display it
   
    if ( code == 0xE7)
    {
      brightness = brightness+1;
      if (brightness > 7 ) brightness = 7; 
      delay(100);
      code = 0;
    }
   if ( code == 0xB5)
   {
     brightness = brightness-1;
     if (brightness < 1) brightness = 1;
     delay(100);
     code = 0;
   }

   if ( code == 0xC7 )
   {
     EEPROM.write(0,brightness);
     EEPROM.commit();
     delay(100);
     code = 0;
     bright = false; 
   } 

   }
 }
}

void SetAutoBright()
{
   code = 0;

  bool autobrt = true;
  
while (autobrt)
{
   IRCodeHandler();

   uint8_t displayData[6];
    displayData[0] = CUSTOM_l;
    displayData[1] = CUSTOM_V;
    displayData[2] = CUSTOM_l;
    displayData[3] = CUSTOM_0;  // Placeholder
    displayData[4] = (autobrightness/10);
    displayData[5] = (autobrightness%10);

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_S,CUSTOM_E,CUSTOM_t,CUSTOM_0, displayData[4],displayData[5]|0x80}; // Set automatic brightness level 0-7
  display2.setSegments(text, 6, 0); // Display it
   
    if ( code == 0xE7)
    {
      autobrightness = autobrightness+1;
      if (autobrightness > 1 ) autobrightness = 1; 
      delay(100);
      code = 0;
    }
   if ( code == 0xB5)
   {
     autobrightness = autobrightness-1;
     if (autobrightness < 0) autobrightness = 0;
     delay(100);
     code = 0;
   }

   if ( code == 0xC7 )
   {
     EEPROM.write(1,autobrightness);
     EEPROM.commit();
     delay(100);
     code = 0;
     autobrt = false; 
   } 

 }
}

void SetChime()
{ 
  DisplaySetChimeText();
  code = 0;

  bool setchm = true;
  
while (setchm)
{
   IRCodeHandler();

   uint8_t displayData[6];
    displayData[0] = CUSTOM_l;
    displayData[1] = CUSTOM_V;
    displayData[2] = CUSTOM_l;
    displayData[3] = CUSTOM_0;  // Placeholder
    displayData[4] = (hourlychime/10);
    displayData[5] = (hourlychime%10);

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_S,CUSTOM_E,CUSTOM_t,CUSTOM_0, displayData[4],displayData[5]|0x80}; // Set hourly chime 1/0
  display2.setSegments(text, 6, 0); // Display it
   
    if ( code == 0xE7)
    {
      hourlychime = hourlychime+1;
      if (hourlychime > 1 ) hourlychime = 1; 
      delay(100);
      code = 0;
    }
   if ( code == 0xB5)
   {
     hourlychime = hourlychime-1;
     if (hourlychime < 0) hourlychime = 0;
     delay(100);
     code = 0;
   }

   if ( code == 0xC7 )
   {
     EEPROM.write(3,hourlychime);
     EEPROM.commit();
     delay(100);
     code = 0;
     setchm = false; 
   } 

 }
}

void Menu()
{
  DisplayMenu();
 code = 0;
  menuitem = 1;
 bool inmenu = true; 
  while (inmenu)
  {
  IRCodeHandler();
  if ( code == 0xEF) // Left button on the remote
   {
    menuitem--;  // Menuitem -1
    code = 0; // Clear code so it wont think it is pressed again or forever 
    if ( menuitem < 1 ) menuitem = 5; 
   }

   if ( code == 0xA5) // Right button on the remote
   {
    menuitem++; // Menuitem +1
    code = 0;
    if ( menuitem > 5 ) menuitem = 1; 
   }

   if ( code == 0x4F) // # Button on the remote
   {
     code = 0;
     delay(100);
     inmenu = false;
   }

   if ( code ==0xC7 ) // OK pressed on the remote
   {
      switch ( menuitem )
      {
        case 1: 
        code = 0;
        delay(100);
        SetDateTime();  
        code = 0;
        break;

        case 2:
        SetBrightness();
        delay(100);
        code = 0;
        break;

        case 3:
         SetAutoBright();
         delay(100);
         code = 0;
        break;

        case 4:
        Switch1224H();
        Set1224H();
        delay(100);
        code = 0;
        break;

        case 5:
        SetChime();
        delay(100);
        code = 0;
        break;

      }
   }
 
 if (menuitem < 1) menuitem = 1; // Menu item can not be less than one
 if (menuitem > 5) menuitem = 5; // Menu tiem can not be more than four
  
  switch ( menuitem )
  {
    case 1:
    DisplaySetClock();
    code = 0;
    break;

    case 2:
    DisplaySetBrightness();
    code = 0;
    break;

    case 3:
    DisplaySetAutoBrightness();
    code = 0;
    break;

    case 4:
    DisplaySet1224H();
    code = 0;
    break;

    case 5:
    DisplaySetChime();
    code = 0;
    break;
  }

  }


}

void CheckTimeMode()
{   
  DisplayTM();
   if ( timeformat == 0)
    {
   
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, CUSTOM_2,CUSTOM_4,CUSTOM_H|0x80, CUSTOM_0}; // Display 24 hour mode
  display2.setSegments(text, 6, 0); // Display it 
    }
 else
 {
  
  uint8_t text[] = {CUSTOM_0,CUSTOM_0, CUSTOM_1,CUSTOM_2,CUSTOM_H|0x80, CUSTOM_0}; // Display 12 hour mode
  display2.setSegments(text, 6, 0); // Display it 
    }
 }


void Switch1224H()
{
   code = 0;

  bool switch1224 = true;
  
while (switch1224) 
{
  SetAMPMText();

   IRCodeHandler();

   uint8_t displayData[6];
    displayData[0] = CUSTOM_l;
    displayData[1] = CUSTOM_V;
    displayData[2] = CUSTOM_l;
    displayData[3] = CUSTOM_0;  // Placeholder
    displayData[4] = (timeformat/10);
    displayData[5] = (timeformat%10);

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_S,CUSTOM_E,CUSTOM_t,CUSTOM_0, displayData[4],displayData[5]|0x80}; // Set 12 / 24H  0 = 24H  1= 12H
  display2.setSegments(text, 6, 0); // Display it
   
    if ( code == 0xE7)
    {
      timeformat = timeformat+1;
      if (timeformat > 1 ) timeformat = 1; 
      delay(100);
      code = 0;
    }
   if ( code == 0xB5)
   {
     timeformat = timeformat-1;
     if (timeformat < 0) timeformat = 0;
     delay(100);
     code = 0;
   }

   if ( code == 0xC7 )
   { 
     EEPROM.write(2,timeformat);  // Puts your seelction to memory
     EEPROM.commit();  // Writes it to the appropriate position for later modify / read
     delay(100);
     code = 0;
     switch1224 = false; 
   } 

 } 
}


void Set1224H()
{ 
  if ( timeformat == 0)
{
  // Do noting , we dont use 12HR
}
 else
  code = 0;

  bool s1224 = true;
  
while (s1224) 
{
  SetAMPMText();

   IRCodeHandler();

   uint8_t displayData[6];
    displayData[0] = CUSTOM_l;
    displayData[1] = CUSTOM_V;
    displayData[2] = CUSTOM_l;
    displayData[3] = CUSTOM_0;  // Placeholder
    displayData[4] = (pmindicator/10);
    displayData[5] = (pmindicator%10);

    for (int i = 0; i < 6; i++) {
    displayData[i] = convertToSegment(displayData[i]);
  }
  uint8_t text[] = {CUSTOM_P,CUSTOM_N,CUSTOM_N,CUSTOM_0, displayData[4],displayData[5]|0x80}; // Set PM to on or off
  display2.setSegments(text, 6, 0); // Display it
   
    if ( code == 0xE7)
    {
      pmindicator = pmindicator+1;
      if (pmindicator > 1 ) pmindicator = 1; 
      delay(100);
      code = 0;
    }
   if ( code == 0xB5)
   {
     pmindicator = pmindicator-1;
     if (pmindicator < 0) pmindicator = 0;
     delay(100);
     code = 0;
   }

   if ( code == 0xC7 )
   { 
     delay(100);
     code = 0;
     s1224 = false; 
   } 

 } 
}

void MelodyTest()
{
   if ( code ==0x67)  // Button 0 pressed
    {
        digitalWrite(ALARMOUT,LOW);
        delay(50);
        digitalWrite(ALARMOUT,HIGH);
        delay(100);
        code = 0;
     }

}

void Purr()
{
   if ( code ==0x6F)  // Button 9 pressed
   {
  for(int i = 0; i < 300; i++)
  {
    int freq = 110 + random(0, 30); // slight randomness
    tone(ALARMIN, freq);
    delay(15);
  }

  noTone(ALARMIN);
   code = 0;
   }
}

void CheckHourlyChime()
{
   GetDateTime();
   
  if ( hourlychime == 1)
   {
     //if ( minute == 0 && second == 0 && hour != lasthour )
     if (minute == 0 && hour != lasthour)
     {
     MelodyTest();
    lasthour = hour;
     }
   }
}


void setup() {
  pinMode(ALARMIN,OUTPUT); // This pin gets pulled low when the alarm is active
  digitalWrite(ALARMIN,HIGH); // Pull high until we need it 
  pinMode(ALARMOUT,OUTPUT); // This pin triggers the alarm chip , literarly
  digitalWrite(ALARMOUT,HIGH); // Set high for idle 
  Serial.begin(115200); // Start and set the serial function and baud rate
  Wire.begin(I2C_SDA,I2C_SCL);  // Start I2C function 
  RTC.begin();  // Start RTC function
  RTC.startClock(); // This library for some unbelievable reason do not do this on its own, so we do it
  EEPROM.begin(1024); // Set a 1K size to use as EEPROM from flash.
  LoadSettings();  // Load time & display related settings from EEPROM
  CheckRTC();  // Check if its running , if not set it and use timezone set up earlier
  display1.setBrightness(brightness); //Set screen 1 brightness according to the value set in EEPROM
  display2.setBrightness(brightness); //Set screen 2 brightness according to the value set in EEPROM
  irDecoder.begin();  // Start the IR receiver function
  aht20.begin();      // Start AHT20 sensor module
  bmp280.begin();     // Start BMP280 sensor module

  
}

void loop() {
  UseLDR();
  GetDateTime();
  CheckHourlyChime();
  if ( timeformat == 1)
   {
    Display12HTime();
   }
  else 
  {
    DisplayTime();
  } 
  DisplayDate();
  CheckHourlyChime();
  IRCodeHandler();
  //Serial.println(code,HEX);
  //Serial.println(RTC.getHourMode());
  ProcessIRCode();
  MelodyTest();
  Purr();
  delay(100);

}
